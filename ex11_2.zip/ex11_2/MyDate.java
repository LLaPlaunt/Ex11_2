package ex11_2;

public interface MyDate {

}
